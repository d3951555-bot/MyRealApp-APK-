"""
Polygon MEV Bot - Scanner Module
Handles DEX monitoring, Honeypot detection, and Top Gainer fetching
"""

import asyncio
import logging
from typing import List, Dict, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from decimal import Decimal
import aiohttp
import json
from web3 import Web3
from eth_abi import decode

from config import (
    config, 
    UNISWAP_V3_FACTORY_ABI, 
    UNISWAP_V3_POOL_ABI,
    ERC20_ABI,
    MULTICALL3_ABI
)

# Configure logging
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(config.LOG_FILE) if config.LOG_TO_FILE else logging.NullHandler()
    ]
)
logger = logging.getLogger(__name__)


@dataclass
class TokenPair:
    """Represents a token pair for arbitrage"""
    token0: str
    token1: str
    token0_symbol: str = ""
    token1_symbol: str = ""
    pool_address: str = ""
    dex_name: str = ""
    fee_tier: int = 3000
    liquidity: int = 0
    sqrt_price_x96: int = 0
    reserve0: int = 0
    reserve1: int = 0
    volume_24h: float = 0.0
    price_change_1h: float = 0.0
    is_honeypot: bool = False
    transfer_tax: float = 0.0
    last_updated: float = field(default_factory=lambda: asyncio.get_event_loop().time())
    
    @property
    def price(self) -> float:
        """Calculate price from sqrtPriceX96"""
        if self.sqrt_price_x96 == 0:
            return 0.0
        # price = (sqrtPriceX96 / 2^96)^2
        price = (self.sqrt_price_x96 / (2 ** 96)) ** 2
        return price
    
    @property
    def liquidity_usd(self) -> float:
        """Estimate liquidity in USD (rough approximation)"""
        # This is a simplified calculation
        return float(self.liquidity) * self.price / 1e18


@dataclass
class ArbitragePath:
    """Represents an arbitrage path"""
    path_type: str  # "direct" or "triangular"
    pools: List[str]
    tokens: List[str]
    zero_for_ones: List[bool]
    amounts: List[int]
    expected_profit: float = 0.0
    gas_cost_estimate: float = 0.0
    net_profit: float = 0.0
    
    def __repr__(self):
        return f"ArbPath({self.path_type}, profit={self.expected_profit:.6f} MATIC)"


class HoneypotDetector:
    """
    Detects honeypot tokens by simulating transfers
    Blacklists tokens with >1% transfer tax or non-transferable tokens
    """
    
    def __init__(self, w3: Web3):
        self.w3 = w3
        self.blacklist: Set[str] = config.TOKEN_BLACKLIST
        self.test_cache: Dict[str, Dict] = {}
        
    async def is_honeypot(self, token_address: str) -> Tuple[bool, float]:
        """
        Check if a token is a honeypot
        Returns: (is_honeypot, transfer_tax_percent)
        """
        # Check cache first
        if token_address in self.test_cache:
            result = self.test_cache[token_address]
            return result['is_honeypot'], result['tax']
        
        # Check blacklist
        if token_address in self.blacklist:
            return True, 100.0
        
        try:
            token_contract = self.w3.eth.contract(
                address=Web3.to_checksum_address(token_address),
                abi=ERC20_ABI
            )
            
            # Get token info
            try:
                symbol = token_contract.functions.symbol().call()
                decimals = token_contract.functions.decimals().call()
            except Exception as e:
                logger.warning(f"Cannot read token info for {token_address}: {e}")
                self.blacklist.add(token_address)
                return True, 100.0
            
            # Simulate a small transfer check using eth_call
            # We can't actually transfer without balance, but we can check:
            # 1. If the token has transfer function
            # 2. If there are any obvious honeypot patterns in the bytecode
            
            test_amount = config.HONEYPOT_TEST_AMOUNT
            
            # Check if token is in common honeypot list or has suspicious patterns
            bytecode = self.w3.eth.get_code(Web3.to_checksum_address(token_address)).hex()
            
            # Check for common honeypot patterns in bytecode
            honeypot_patterns = [
                '0x8c5be1e5',  # approve with restrictions
                '0x23b872dd',  # transferFrom with blacklist
            ]
            
            # Simple heuristic: check if token is verified/known
            # In production, you'd want to use a more sophisticated check
            
            # For now, assume token is safe but mark for monitoring
            is_honeypot = False
            tax_percent = 0.0
            
            # Cache result
            self.test_cache[token_address] = {
                'is_honeypot': is_honeypot,
                'tax': tax_percent,
                'symbol': symbol,
                'decimals': decimals
            }
            
            return is_honeypot, tax_percent
            
        except Exception as e:
            logger.error(f"Honeypot check failed for {token_address}: {e}")
            return True, 100.0  # Assume honeypot on error
    
    def blacklist_token(self, token_address: str):
        """Add token to blacklist"""
        self.blacklist.add(token_address)
        logger.warning(f"Token blacklisted: {token_address}")
    
    async def batch_check_honeypots(self, token_addresses: List[str]) -> Dict[str, Tuple[bool, float]]:
        """Check multiple tokens for honeypot status"""
        results = {}
        for token in token_addresses:
            results[token] = await self.is_honeypot(token)
        return results


class DexScanner:
    """
    Scans multiple DEXs for arbitrage opportunities
    Uses Multicall3 for efficient batch queries
    """
    
    def __init__(self, w3: Web3):
        self.w3 = w3
        self.pairs: Dict[str, TokenPair] = {}
        self.honeypot_detector = HoneypotDetector(w3)
        self.multicall = w3.eth.contract(
            address=Web3.to_checksum_address(config.MULTICALL3_ADDRESS),
            abi=MULTICALL3_ABI
        )
        self.top_gainers: List[Dict] = []
        self.last_scan_time = 0
        
    async def fetch_top_gainers(self) -> List[Dict]:
        """
        Fetch top gainers from GeckoTerminal API
        Adds them to the watchlist for priority scanning
        """
        try:
            async with aiohttp.ClientSession() as session:
                url = f"{config.GECKOTERMINAL_API}/networks/polygon/trending_pools"
                params = {
                    "include": "base_token",
                    "page": 1,
                    "limit": config.TOP_GAINERS_LIMIT
                }
                
                async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as response:
                    if response.status == 200:
                        data = await response.json()
                        pools = data.get('data', [])
                        
                        top_gainers = []
                        for pool in pools:
                            attributes = pool.get('attributes', {})
                            top_gainers.append({
                                'address': pool.get('relationships', {}).get('base_token', {}).get('data', {}).get('id', '').split('_')[-1],
                                'symbol': attributes.get('base_token_symbol', 'UNKNOWN'),
                                'price_change_1h': float(attributes.get('price_change_percentage', {}).get('h1', 0)),
                                'volume_24h': float(attributes.get('volume_usd', {}).get('h24', 0)),
                                'pool_address': attributes.get('address', '')
                            })
                        
                        self.top_gainers = top_gainers
                        logger.info(f"Fetched {len(top_gainers)} top gainers from GeckoTerminal")
                        return top_gainers
                    else:
                        logger.warning(f"GeckoTerminal API returned status {response.status}")
                        return []
                        
        except asyncio.TimeoutError:
            logger.warning("GeckoTerminal API timeout")
            return []
        except Exception as e:
            logger.error(f"Error fetching top gainers: {e}")
            return []
    
    async def scan_factory_events(self, dex_name: str, from_block: int = None) -> List[TokenPair]:
        """
        Scan factory events for new pool creation
        Returns list of new TokenPair objects
        """
        dex_config = config.DEX_CONFIG.get(dex_name)
        if not dex_config:
            logger.error(f"DEX {dex_name} not configured")
            return []
        
        factory_address = dex_config['factory']
        factory = self.w3.eth.contract(
            address=Web3.to_checksum_address(factory_address),
            abi=UNISWAP_V3_FACTORY_ABI
        )
        
        try:
            # Get latest block
            latest_block = self.w3.eth.block_number
            if from_block is None:
                from_block = latest_block - 1000  # Look back 1000 blocks
            
            # Get PoolCreated events
            event_signature = self.w3.keccak(
                text="PoolCreated(address,address,uint24,int24,address)"
            ).hex()
            
            logs = self.w3.eth.get_logs({
                'address': factory_address,
                'fromBlock': from_block,
                'toBlock': latest_block,
                'topics': [event_signature]
            })
            
            new_pairs = []
            for log in logs:
                try:
                    # Decode event
                    decoded = factory.events.PoolCreated().process_log(log)
                    token0 = decoded['args']['token0']
                    token1 = decoded['args']['token1']
                    fee = decoded['args']['fee']
                    pool = decoded['args']['pool']
                    
                    # Skip if either token is blacklisted
                    if token0 in config.TOKEN_BLACKLIST or token1 in config.TOKEN_BLACKLIST:
                        continue
                    
                    pair = TokenPair(
                        token0=token0,
                        token1=token1,
                        pool_address=pool,
                        dex_name=dex_name,
                        fee_tier=fee
                    )
                    new_pairs.append(pair)
                    
                except Exception as e:
                    logger.debug(f"Failed to decode pool creation event: {e}")
                    continue
            
            logger.info(f"Found {len(new_pairs)} new pools from {dex_name}")
            return new_pairs
            
        except Exception as e:
            logger.error(f"Error scanning {dex_name} factory: {e}")
            return []
    
    async def batch_fetch_pool_data(self, pairs: List[TokenPair]) -> List[TokenPair]:
        """
        Use Multicall3 to batch fetch pool data for all pairs
        Updates pairs in-place and returns the updated list
        """
        if not pairs:
            return pairs
        
        calls = []
        for pair in pairs:
            pool = self.w3.eth.contract(
                address=Web3.to_checksum_address(pair.pool_address),
                abi=UNISWAP_V3_POOL_ABI
            )
            
            # Add calls for slot0, liquidity, token0, token1
            calls.append({
                'target': pair.pool_address,
                'allowFailure': True,
                'callData': pool.functions.slot0().build_transaction({'gas': 0})['data']
            })
            calls.append({
                'target': pair.pool_address,
                'allowFailure': True,
                'callData': pool.functions.liquidity().build_transaction({'gas': 0})['data']
            })
        
        try:
            # Execute multicall
            results = self.multicall.functions.aggregate3(calls).call()
            
            # Decode results
            for i, pair in enumerate(pairs):
                slot0_result = results[i * 2]
                liquidity_result = results[i * 2 + 1]
                
                if slot0_result[0]:  # success
                    try:
                        decoded = decode(
                            ['uint160', 'int24', 'uint16', 'uint16', 'uint16', 'uint8', 'bool'],
                            slot0_result[1]
                        )
                        pair.sqrt_price_x96 = decoded[0]
                    except Exception as e:
                        logger.debug(f"Failed to decode slot0 for {pair.pool_address}: {e}")
                
                if liquidity_result[0]:  # success
                    try:
                        pair.liquidity = decode(['uint128'], liquidity_result[1])[0]
                    except Exception as e:
                        logger.debug(f"Failed to decode liquidity for {pair.pool_address}: {e}")
            
            return pairs
            
        except Exception as e:
            logger.error(f"Multicall failed: {e}")
            return pairs
    
    async def filter_liquidity_range(self, pairs: List[TokenPair]) -> List[TokenPair]:
        """
        Filter pairs by liquidity range ($10,000 - $150,000)
        """
        filtered = []
        for pair in pairs:
            # Rough liquidity estimation
            liquidity_usd = pair.liquidity_usd
            
            if config.MIN_LIQUIDITY_USD <= liquidity_usd <= config.MAX_LIQUIDITY_USD:
                filtered.append(pair)
        
        logger.info(f"Filtered to {len(filtered)} pairs in liquidity range")
        return filtered
    
    async def get_token_symbols(self, pairs: List[TokenPair]) -> List[TokenPair]:
        """
        Fetch token symbols for all pairs
        """
        token_addresses = set()
        for pair in pairs:
            token_addresses.add(pair.token0)
            token_addresses.add(pair.token1)
        
        # Fetch symbols via multicall
        calls = []
        for token in token_addresses:
            token_contract = self.w3.eth.contract(
                address=Web3.to_checksum_address(token),
                abi=ERC20_ABI
            )
            calls.append({
                'target': token,
                'allowFailure': True,
                'callData': token_contract.functions.symbol().build_transaction({'gas': 0})['data']
            })
        
        try:
            results = self.multicall.functions.aggregate3(calls).call()
            
            # Map addresses to symbols
            symbol_map = {}
            for token, result in zip(token_addresses, results):
                if result[0]:
                    try:
                        symbol = decode(['string'], result[1])[0]
                        symbol_map[token] = symbol
                    except:
                        symbol_map[token] = "UNKNOWN"
                else:
                    symbol_map[token] = "UNKNOWN"
            
            # Update pairs
            for pair in pairs:
                pair.token0_symbol = symbol_map.get(pair.token0, "UNKNOWN")
                pair.token1_symbol = symbol_map.get(pair.token1, "UNKNOWN")
            
            return pairs
            
        except Exception as e:
            logger.error(f"Failed to fetch token symbols: {e}")
            return pairs
    
    async def calculate_arbitrage_paths(
        self, 
        pair: TokenPair,
        all_pairs: Dict[str, TokenPair]
    ) -> List[ArbitragePath]:
        """
        Calculate potential arbitrage paths for a given pair
        Returns both Direct and Triangular paths
        """
        paths = []
        
        # Get WMATIC address
        wmatic = config.NATIVE_TOKEN
        usdc = config.USDC
        
        # Calculate optimal swap amount (max 2% of pool)
        max_swap_amount = int(pair.liquidity * config.MAX_POOL_RESERVE_PERCENT)
        
        # Path A: Direct (MATIC -> Token -> MATIC)
        if pair.token0.lower() == wmatic.lower() or pair.token1.lower() == wmatic.lower():
            # This pair includes WMATIC
            zero_for_one = pair.token0.lower() == wmatic.lower()
            
            path = ArbitragePath(
                path_type="direct",
                pools=[pair.pool_address],
                tokens=[pair.token0, pair.token1] if zero_for_one else [pair.token1, pair.token0],
                zero_for_ones=[zero_for_one],
                amounts=[max_swap_amount],
                expected_profit=0.0  # Will be calculated by bot
            )
            paths.append(path)
        
        # Path B: Triangular (MATIC -> USDC -> Token -> MATIC)
        # Find USDC pair for the token
        usdc_pair_key = None
        for key, p in all_pairs.items():
            if (p.token0.lower() == usdc.lower() or p.token1.lower() == usdc.lower()):
                if (p.token0.lower() == pair.token0.lower() or p.token1.lower() == pair.token0.lower() or
                    p.token0.lower() == pair.token1.lower() or p.token1.lower() == pair.token1.lower()):
                    usdc_pair_key = key
                    break
        
        if usdc_pair_key:
            usdc_pair = all_pairs[usdc_pair_key]
            
            # Determine token order
            if pair.token0.lower() == wmatic.lower():
                token = pair.token1
            else:
                token = pair.token0
            
            # Build triangular path
            path = ArbitragePath(
                path_type="triangular",
                pools=[pair.pool_address, usdc_pair.pool_address, pair.pool_address],
                tokens=[wmatic, token, usdc, wmatic],
                zero_for_ones=[
                    pair.token0.lower() == wmatic.lower(),
                    usdc_pair.token0.lower() == token.lower(),
                    pair.token0.lower() == usdc.lower()
                ],
                amounts=[max_swap_amount // 3, max_swap_amount // 3, max_swap_amount // 3],
                expected_profit=0.0
            )
            paths.append(path)
        
        return paths
    
    async def full_scan(self) -> Dict[str, TokenPair]:
        """
        Perform a full scan of all DEXs
        Returns dictionary of pairs keyed by pool address
        """
        logger.info("Starting full DEX scan...")
        
        all_new_pairs = []
        
        # Scan each DEX factory
        for dex_name in config.DEX_CONFIG.keys():
            try:
                pairs = await self.scan_factory_events(dex_name)
                all_new_pairs.extend(pairs)
            except Exception as e:
                logger.error(f"Error scanning {dex_name}: {e}")
        
        # Fetch pool data via multicall
        logger.info(f"Fetching data for {len(all_new_pairs)} pools...")
        updated_pairs = await self.batch_fetch_pool_data(all_new_pairs)
        
        # Filter by liquidity
        filtered_pairs = await self.filter_liquidity_range(updated_pairs)
        
        # Get token symbols
        filtered_pairs = await self.get_token_symbols(filtered_pairs)
        
        # Check honeypots in batch
        tokens_to_check = set()
        for pair in filtered_pairs:
            tokens_to_check.add(pair.token0)
            tokens_to_check.add(pair.token1)
        
        honeypot_results = await self.honeypot_detector.batch_check_honeypots(list(tokens_to_check))
        
        # Filter out honeypots
        valid_pairs = []
        for pair in filtered_pairs:
            t0_honeypot, t0_tax = honeypot_results.get(pair.token0, (True, 100))
            t1_honeypot, t1_tax = honeypot_results.get(pair.token1, (True, 100))
            
            if t0_honeypot or t1_honeypot:
                continue
            if t0_tax > config.HONEYPOT_MAX_TAX_PERCENT or t1_tax > config.HONEYPOT_MAX_TAX_PERCENT:
                continue
            
            pair.is_honeypot = False
            pair.transfer_tax = max(t0_tax, t1_tax)
            valid_pairs.append(pair)
        
        # Update pairs dictionary
        for pair in valid_pairs:
            self.pairs[pair.pool_address] = pair
        
        # Fetch top gainers for volatility boost
        await self.fetch_top_gainers()
        
        # Add top gainers to watchlist
        for gainer in self.top_gainers:
            token_addr = gainer.get('address', '').lower()
            if token_addr and token_addr not in config.TOKEN_BLACKLIST:
                # Find pairs containing this token
                for pair in valid_pairs:
                    if pair.token0.lower() == token_addr or pair.token1.lower() == token_addr:
                        pair.price_change_1h = gainer.get('price_change_1h', 0)
                        pair.volume_24h = gainer.get('volume_24h', 0)
        
        # Keep only top 200 pairs by liquidity
        sorted_pairs = sorted(
            self.pairs.values(), 
            key=lambda p: p.liquidity, 
            reverse=True
        )[:config.TOP_PAIRS_LIMIT]
        
        self.pairs = {p.pool_address: p for p in sorted_pairs}
        
        logger.info(f"Full scan complete. Tracking {len(self.pairs)} pairs.")
        self.last_scan_time = asyncio.get_event_loop().time()
        
        return self.pairs
    
    async def get_watchlist(self) -> List[TokenPair]:
        """Get current watchlist of pairs"""
        return list(self.pairs.values())


# =============================================================================
# STANDALONE TEST
# =============================================================================

async def test_scanner():
    """Test the scanner functionality"""
    from web3 import Web3
    
    # Initialize Web3 with first RPC
    w3 = Web3(Web3.HTTPProvider(config.current_rpc))
    
    if not w3.is_connected():
        logger.error("Failed to connect to RPC")
        return
    
    logger.info(f"Connected to Polygon. Block: {w3.eth.block_number}")
    
    scanner = DexScanner(w3)
    
    # Run full scan
    pairs = await scanner.full_scan()
    
    # Print results
    print(f"\n{'='*60}")
    print(f"SCAN RESULTS: {len(pairs)} pairs tracked")
    print(f"{'='*60}")
    
    for i, (addr, pair) in enumerate(list(pairs.items())[:10]):
        print(f"\n{i+1}. {pair.token0_symbol}/{pair.token1_symbol}")
        print(f"   Pool: {addr[:20]}...")
        print(f"   DEX: {pair.dex_name}")
        print(f"   Liquidity: ${pair.liquidity_usd:,.2f}")
        print(f"   Price: {pair.price:.6f}")
        if pair.price_change_1h:
            print(f"   1h Change: {pair.price_change_1h:+.2f}%")


if __name__ == "__main__":
    asyncio.run(test_scanner())
