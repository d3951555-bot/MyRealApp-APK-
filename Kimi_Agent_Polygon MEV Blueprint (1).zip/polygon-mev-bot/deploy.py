"""
Polygon God-Mode MEV Bot - Deployment Script
Deploys GodFlash contract with maximum optimization
Target: < 0.45 POL deployment cost
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, Optional, Tuple
from web3 import Web3
from web3.middleware import geth_poa_middleware
from eth_account import Account
from solcx import compile_standard, install_solc, get_installed_solc_versions
import solcx

from config import config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ContractDeployer:
    """
    Smart contract deployer with optimization
    Uses solc with 10,000 optimizer runs
    """
    
    # Target deployment cost: < 0.45 POL
    MAX_DEPLOYMENT_COST_POL = 0.45
    
    def __init__(self):
        self.w3: Optional[Web3] = None
        self.account: Optional[Account] = None
        self.compiled_contracts: Dict = {}
        
    def setup_web3(self, rpc_url: str = None) -> Web3:
        """Initialize Web3 connection"""
        rpc = rpc_url or config.current_rpc
        
        w3 = Web3(Web3.HTTPProvider(rpc))
        w3.middleware_onion.inject(geth_poa_middleware, layer=0)
        
        if not w3.is_connected():
            raise ConnectionError(f"Failed to connect to RPC: {rpc}")
        
        logger.info(f"Connected to Polygon. Block: {w3.eth.block_number}")
        self.w3 = w3
        return w3
    
    def setup_account(self, private_key: str = None) -> Account:
        """Load deployer account"""
        key = private_key or config.PRIVATE_KEY
        
        if not key or key == "0xYOUR_PRIVATE_KEY_HERE":
            raise ValueError("Private key not configured. Set PRIVATE_KEY in config.py or environment.")
        
        self.account = Account.from_key(key)
        logger.info(f"Account loaded: {self.account.address}")
        
        # Check balance
        balance = self.w3.eth.get_balance(self.account.address)
        balance_pol = self.w3.from_wei(balance, 'ether')
        logger.info(f"Account balance: {balance_pol:.4f} POL")
        
        if balance_pol < self.MAX_DEPLOYMENT_COST_POL:
            logger.warning(f"Low balance! Need at least {self.MAX_DEPLOYMENT_COST_POL} POL for deployment")
        
        return self.account
    
    def install_compiler(self, version: str = "0.8.26"):
        """Install Solidity compiler"""
        try:
            installed = get_installed_solc_versions()
            if version not in installed:
                logger.info(f"Installing Solidity {version}...")
                install_solc(version)
            else:
                logger.info(f"Solidity {version} already installed")
            
            solcx.set_solc_version(version)
            logger.info(f"Using Solidity {version}")
            
        except Exception as e:
            logger.error(f"Failed to install Solidity: {e}")
            raise
    
    def compile_contract(
        self,
        contract_path: str,
        contract_name: str = "GodFlash",
        optimizer_runs: int = 10000
    ) -> Dict:
        """
        Compile Solidity contract with optimization
        
        Args:
            contract_path: Path to .sol file
            contract_name: Name of the contract to compile
            optimizer_runs: Optimizer runs (higher = smaller bytecode but more gas for calls)
            
        Returns:
            Compiled contract data
        """
        logger.info(f"Compiling {contract_name} from {contract_path}...")
        logger.info(f"Optimizer runs: {optimizer_runs}")
        
        # Read contract source
        with open(contract_path, 'r') as f:
            source = f.read()
        
        # Compile with optimization
        compiled = compile_standard(
            {
                "language": "Solidity",
                "sources": {
                    os.path.basename(contract_path): {
                        "content": source
                    }
                },
                "settings": {
                    "optimizer": {
                        "enabled": True,
                        "runs": optimizer_runs
                    },
                    "viaIR": True,  # Enable via-IR optimization
                    "outputSelection": {
                        "*": {
                            "*": [
                                "abi",
                                "evm.bytecode.object",
                                "evm.bytecode.sourceMap",
                                "evm.deployedBytecode.object",
                                "evm.gasEstimates"
                            ]
                        }
                    }
                }
            },
            solc_version="0.8.26"
        )
        
        # Extract contract data
        contract_data = compiled['contracts'][os.path.basename(contract_path)][contract_name]
        
        abi = contract_data['abi']
        bytecode = contract_data['evm']['bytecode']['object']
        deployed_bytecode = contract_data['evm']['deployedBytecode']['object']
        
        # Calculate bytecode size
        bytecode_size = len(bytecode) // 2
        deployed_size = len(deployed_bytecode) // 2
        
        logger.info(f"Compilation successful!")
        logger.info(f"  Bytecode size: {bytecode_size} bytes")
        logger.info(f"  Deployed size: {deployed_size} bytes")
        logger.info(f"  Max size: 24576 bytes (EIP-170)")
        
        if deployed_size > 24576:
            logger.warning("WARNING: Contract exceeds EIP-170 size limit!")
        
        # Store compiled data
        self.compiled_contracts[contract_name] = {
            'abi': abi,
            'bytecode': bytecode,
            'deployed_bytecode': deployed_bytecode,
            'bytecode_size': bytecode_size,
            'deployed_size': deployed_size
        }
        
        return self.compiled_contracts[contract_name]
    
    def estimate_deployment_cost(self, contract_name: str = "GodFlash") -> Tuple[float, Dict]:
        """
        Estimate deployment gas cost
        
        Returns:
            (cost_in_pol, gas_estimate_dict)
        """
        contract = self.compiled_contracts.get(contract_name)
        if not contract:
            raise ValueError(f"Contract {contract_name} not compiled")
        
        # Estimate gas
        gas_estimate = self.w3.eth.estimate_gas({
            'from': self.account.address,
            'data': '0x' + contract['bytecode']
        })
        
        # Get current gas price
        gas_price = self.w3.eth.gas_price
        gas_price_gwei = self.w3.from_wei(gas_price, 'gwei')
        
        # Calculate cost
        cost_wei = gas_estimate * gas_price
        cost_pol = self.w3.from_wei(cost_wei, 'ether')
        
        logger.info(f"Deployment estimate:")
        logger.info(f"  Gas estimate: {gas_estimate:,}")
        logger.info(f"  Gas price: {gas_price_gwei:.2f} gwei")
        logger.info(f"  Cost: {cost_pol:.6f} POL")
        
        return float(cost_pol), {
            'gas_estimate': gas_estimate,
            'gas_price': gas_price,
            'cost_wei': cost_wei,
            'cost_pol': cost_pol
        }
    
    def deploy_contract(
        self,
        contract_name: str = "GodFlash",
        constructor_args: list = None,
        confirm: bool = True
    ) -> Tuple[str, str]:
        """
        Deploy compiled contract
        
        Args:
            contract_name: Name of compiled contract
            constructor_args: Constructor arguments
            confirm: Wait for confirmation
            
        Returns:
            (contract_address, transaction_hash)
        """
        contract = self.compiled_contracts.get(contract_name)
        if not contract:
            raise ValueError(f"Contract {contract_name} not compiled")
        
        # Get constructor args
        args = constructor_args or []
        
        # Build contract
        Contract = self.w3.eth.contract(
            abi=contract['abi'],
            bytecode=contract['bytecode']
        )
        
        # Build deployment transaction
        if args:
            tx = Contract.constructor(*args).build_transaction({
                'from': self.account.address,
                'nonce': self.w3.eth.get_transaction_count(self.account.address),
                'gas': 5000000,  # Will be estimated
                'maxFeePerGas': self.w3.to_wei(config.MAX_GAS_PRICE_GWEI, 'gwei'),
                'maxPriorityFeePerGas': self.w3.to_wei(config.PRIORITY_FEE_GWEI, 'gwei'),
                'chainId': config.CHAIN_ID
            })
        else:
            tx = Contract.constructor().build_transaction({
                'from': self.account.address,
                'nonce': self.w3.eth.get_transaction_count(self.account.address),
                'gas': 5000000,
                'maxFeePerGas': self.w3.to_wei(config.MAX_GAS_PRICE_GWEI, 'gwei'),
                'maxPriorityFeePerGas': self.w3.to_wei(config.PRIORITY_FEE_GWEI, 'gwei'),
                'chainId': config.CHAIN_ID
            })
        
        # Estimate gas
        try:
            gas_estimate = self.w3.eth.estimate_gas(tx)
            tx['gas'] = int(gas_estimate * 1.2)  # Add 20% buffer
            logger.info(f"Gas estimate: {gas_estimate:,}")
        except Exception as e:
            logger.warning(f"Gas estimation failed: {e}")
            logger.warning("Using default gas limit")
        
        # Sign and send
        logger.info("Signing deployment transaction...")
        signed_tx = self.account.sign_transaction(tx)
        
        logger.info("Sending deployment transaction...")
        tx_hash = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction)
        tx_hash_hex = tx_hash.hex()
        
        logger.info(f"Transaction sent: {tx_hash_hex}")
        
        if confirm:
            logger.info("Waiting for confirmation...")
            receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
            
            if receipt['status'] == 1:
                contract_address = receipt['contractAddress']
                gas_used = receipt['gasUsed']
                actual_cost = self.w3.from_wei(gas_used * self.w3.eth.gas_price, 'ether')
                
                logger.info("=" * 60)
                logger.info("DEPLOYMENT SUCCESSFUL!")
                logger.info("=" * 60)
                logger.info(f"Contract Address: {contract_address}")
                logger.info(f"Transaction Hash: {tx_hash_hex}")
                logger.info(f"Gas Used: {gas_used:,}")
                logger.info(f"Actual Cost: {actual_cost:.6f} POL")
                logger.info("=" * 60)
                
                # Save deployment info
                self._save_deployment_info(contract_name, contract_address, tx_hash_hex, receipt)
                
                return contract_address, tx_hash_hex
            else:
                raise RuntimeError(f"Deployment failed! Status: {receipt['status']}")
        else:
            return None, tx_hash_hex
    
    def _save_deployment_info(
        self,
        contract_name: str,
        contract_address: str,
        tx_hash: str,
        receipt: Dict
    ):
        """Save deployment information to file"""
        deployment_info = {
            'contract_name': contract_name,
            'contract_address': contract_address,
            'transaction_hash': tx_hash,
            'deployer': self.account.address,
            'block_number': receipt['blockNumber'],
            'gas_used': receipt['gasUsed'],
            'chain_id': config.CHAIN_ID,
            'network': 'polygon',
            'timestamp': receipt.get('timestamp', None)
        }
        
        # Save to JSON
        output_path = Path(f'deployment_{contract_name.lower()}_{receipt["blockNumber"]}.json')
        with open(output_path, 'w') as f:
            json.dump(deployment_info, f, indent=2)
        
        logger.info(f"Deployment info saved to {output_path}")
        
        # Also update config.py with new contract address
        logger.info(f"\nIMPORTANT: Update config.py with:")
        logger.info(f'  GODFLASH_CONTRACT = "{contract_address}"')
    
    def verify_contract(
        self,
        contract_address: str,
        contract_name: str = "GodFlash"
    ):
        """
        Verify contract on Polygonscan
        Note: Requires POLYGONSCAN_API_KEY environment variable
        """
        api_key = os.getenv('POLYGONSCAN_API_KEY')
        if not api_key:
            logger.warning("POLYGONSCAN_API_KEY not set, skipping verification")
            return
        
        contract = self.compiled_contracts.get(contract_name)
        if not contract:
            raise ValueError(f"Contract {contract_name} not compiled")
        
        # This would require implementing Polygonscan API verification
        # For now, just log instructions
        logger.info("\nTo verify on Polygonscan:")
        logger.info(f"1. Go to https://polygonscan.com/address/{contract_address}#code")
        logger.info("2. Click 'Verify and Publish'")
        logger.info(f"3. Compiler: Solidity {solcx.get_solc_version()}")
        logger.info("4. Optimization: Enabled with 10,000 runs")
        logger.info("5. Paste the contract source code")


def deploy_godflash():
    """
    Main deployment function for GodFlash contract
    """
    deployer = ContractDeployer()
    
    try:
        # Setup
        logger.info("=" * 60)
        logger.info("GODFLASH DEPLOYMENT")
        logger.info("=" * 60)
        
        deployer.setup_web3()
        deployer.setup_account()
        deployer.install_compiler("0.8.26")
        
        # Compile
        contract_path = Path(__file__).parent / "contracts" / "GodFlash.sol"
        deployer.compile_contract(
            str(contract_path),
            "GodFlash",
            optimizer_runs=10000
        )
        
        # Estimate cost
        cost_pol, estimate = deployer.estimate_deployment_cost("GodFlash")
        
        if cost_pol > deployer.MAX_DEPLOYMENT_COST_POL:
            logger.warning(f"Estimated cost ({cost_pol:.4f} POL) exceeds target!")
            response = input("Continue anyway? (y/n): ")
            if response.lower() != 'y':
                logger.info("Deployment cancelled")
                return
        
        # Deploy with WMATIC address
        wmatic_address = config.NATIVE_TOKEN
        contract_address, tx_hash = deployer.deploy_contract(
            "GodFlash",
            constructor_args=[wmatic_address]
        )
        
        # Verify
        if contract_address:
            deployer.verify_contract(contract_address, "GodFlash")
        
        logger.info("\nDeployment complete!")
        
    except Exception as e:
        logger.error(f"Deployment failed: {e}")
        raise


def deploy_factory():
    """
    Deploy GodFlashFactory contract
    """
    deployer = ContractDeployer()
    
    try:
        logger.info("=" * 60)
        logger.info("GODFLASH FACTORY DEPLOYMENT")
        logger.info("=" * 60)
        
        deployer.setup_web3()
        deployer.setup_account()
        deployer.install_compiler("0.8.26")
        
        # Compile
        contract_path = Path(__file__).parent / "contracts" / "GodFlash.sol"
        deployer.compile_contract(
            str(contract_path),
            "GodFlashFactory",
            optimizer_runs=10000
        )
        
        # Deploy
        wmatic_address = config.NATIVE_TOKEN
        contract_address, tx_hash = deployer.deploy_contract(
            "GodFlashFactory",
            constructor_args=[wmatic_address]
        )
        
        logger.info("\nFactory deployment complete!")
        
    except Exception as e:
        logger.error(f"Factory deployment failed: {e}")
        raise


def quick_deploy():
    """
    Quick deployment with minimal output
    """
    deployer = ContractDeployer()
    
    deployer.setup_web3()
    deployer.setup_account()
    deployer.install_compiler("0.8.26")
    
    contract_path = Path(__file__).parent / "contracts" / "GodFlash.sol"
    deployer.compile_contract(str(contract_path), "GodFlash", optimizer_runs=10000)
    
    wmatic_address = config.NATIVE_TOKEN
    contract_address, tx_hash = deployer.deploy_contract("GodFlash", constructor_args=[wmatic_address])
    
    print(f"\n{'='*60}")
    print(f"GODFLASH DEPLOYED")
    print(f"{'='*60}")
    print(f"Address: {contract_address}")
    print(f"Tx Hash: {tx_hash}")
    print(f"{'='*60}")
    
    return contract_address


if __name__ == "__main__":
    import sys
    
    # Check command line args
    if len(sys.argv) > 1:
        if sys.argv[1] == "factory":
            deploy_factory()
        elif sys.argv[1] == "quick":
            quick_deploy()
        else:
            print("Usage: python deploy.py [factory|quick]")
    else:
        deploy_godflash()
