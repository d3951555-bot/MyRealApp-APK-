"""
Polygon God-Mode MEV Bot Configuration
$5 Budget Optimized - Gas Efficiency First
"""

import os
from dataclasses import dataclass
from typing import List, Dict

# =============================================================================
# CRITICAL: SECURITY WARNING
# =============================================================================
"""
NEVER commit this file with real private keys to GitHub.
Use environment variables or .env file in production.
"""

@dataclass
class Config:
    """Main configuration class for the MEV Bot"""
    
    # ==========================================================================
    # WALLET CONFIGURATION
    # ==========================================================================
    PRIVATE_KEY: str = os.getenv("PRIVATE_KEY", "0xYOUR_PRIVATE_KEY_HERE")
    WALLET_ADDRESS: str = os.getenv("WALLET_ADDRESS", "0xYOUR_WALLET_ADDRESS")
    
    # ==========================================================================
    # RPC ROTATION SYSTEM (Anti-Ban)
    # 5+ Public RPCs to rotate through for each Multicall
    # ==========================================================================
    RPC_URLS: List[str] = None
    
    def __post_init__(self):
        self.RPC_URLS = [
            # Primary public RPCs (free tier)
            "https://polygon-rpc.com",
            "https://rpc.ankr.com/polygon",
            "https://polygon.llamarpc.com",
            "https://poly-rpc.gateway.pokt.network",
            "https://polygon-bor.publicnode.com",
            "https://polygon.drpc.org",
            "https://polygon.meowrpc.com",
            "https://polygon.rpc.blxrbdn.com",
        ]
    
    # Current RPC index for rotation
    current_rpc_index: int = 0
    
    @property
    def current_rpc(self) -> str:
        """Get current RPC URL"""
        return self.RPC_URLS[self.current_rpc_index % len(self.RPC_URLS)]
    
    def rotate_rpc(self) -> str:
        """Rotate to next RPC and return it"""
        self.current_rpc_index = (self.current_rpc_index + 1) % len(self.RPC_URLS)
        return self.current_rpc
    
    # ==========================================================================
    # NETWORK CONFIGURATION
    # ==========================================================================
    CHAIN_ID: int = 137
    NATIVE_TOKEN: str = "0x0000000000000000000000000000000000001010"  # WMATIC
    USDC: str = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"
    USDT: str = "0xc2132D05D31c914a87C6611C10748AEb04B58e8F"
    DAI: str = "0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063"
    
    # ==========================================================================
    # DEX CONFIGURATION
    # ==========================================================================
    DEX_CONFIG: Dict = None
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == "DEX_CONFIG" and value is None:
            self.DEX_CONFIG = {
                "uniswap_v3": {
                    "factory": "0x1F98431c8aD98523631AE4a59f267346ea31F984",
                    "quoter": "0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6",
                    "router": "0xE592427A0AEce92De3Edee1F18E0157C05861564",
                    "fee_tiers": [500, 3000, 10000],  # 0.05%, 0.3%, 1%
                },
                "quickswap_v3": {
                    "factory": "0x411b0fAcC3E93eF5F87A3B6bd58198AfB41A80cf",
                    "quoter": "0xa15F0D737ceB8E70ae1e47C3575FC656D289C5bE",
                    "router": "0xf5b509bB0909a69B1c207E495f687a596C168E12",
                    "fee_tiers": [500, 3000, 10000],
                },
                "sushiswap_v3": {
                    "factory": "0x917933899c6a5F8E37F31E19f92CdBFF7e8FF0e2",
                    "quoter": "0x64e8802FE490fa7Cc61d3463958199161E60814f",
                    "router": "0x2E6cd2d30aa43f40aa81619ff4b6E0a41479B13F",
                    "fee_tiers": [500, 3000, 10000],
                },
                "retro": {
                    "factory": "0x91e1B99072f5D4e4Ab5c445991BD834D3dC0C644",
                    "quoter": "0x5x3b1dE4593b13ddEca69C522745E6dc9edEcEA17",  # Placeholder
                    "router": "0x7b3eE5f3f8Dda69d5D7bb2C60eD0900bD7f0f5f8",  # Placeholder
                    "fee_tiers": [500, 3000, 10000],
                }
            }
    
    # ==========================================================================
    # MULTICALL3 CONFIGURATION
    # ==========================================================================
    MULTICALL3_ADDRESS: str = "0xcA11bde05977b3631167028862bE2a173976CA11"
    MULTICALL_BATCH_SIZE: int = 100  # Max calls per multicall
    
    # ==========================================================================
    # FASTLANE PROTOCOL CONFIGURATION
    # ==========================================================================
    FASTLANE_ENABLED: bool = True
    FASTLANE_RELAY_URL: str = "https://polygon.fastlane.xyz"
    FASTLANE_RELAY_ADDRESS: str = "0x5x3b1dE4593b13ddEca69C522745E6dc9edEcEA17"  # Update with actual
    
    # ==========================================================================
    # BOT OPERATION MODES
    # ==========================================================================
    SIMULATION_MODE: bool = True  # Default: True - Only simulate, no real trades
    SIMULATION_LOG_PROFIT: bool = True  # Log potential profits in simulation
    
    # ==========================================================================
    # SCANNER CONFIGURATION
    # ==========================================================================
    SCAN_INTERVAL: float = 2.2  # Seconds between scans (as requested)
    TOP_PAIRS_LIMIT: int = 200
    MIN_LIQUIDITY_USD: float = 10000
    MAX_LIQUIDITY_USD: float = 150000
    MAX_POOL_RESERVE_PERCENT: float = 0.02  # Max 2% of pool reserves
    
    # Honeypot detection
    HONEYPOT_MAX_TAX_PERCENT: float = 1.0  # Blacklist if tax > 1%
    HONEYPOT_TEST_AMOUNT: int = 1000  # Small amount for honeypot test
    
    # Volatility boost
    GECKOTERMINAL_API: str = "https://api.geckoterminal.com/api/v2"
    TOP_GAINERS_LIMIT: int = 20
    TOP_GAINERS_TIMEFRAME: str = "1h"
    
    # ==========================================================================
    # GAS CONFIGURATION (Critical for $5 budget)
    # ==========================================================================
    MAX_GAS_PRICE_GWEI: int = 500  # Maximum gas price willing to pay
    MAX_GAS_LIMIT: int = 500000   # Maximum gas limit per transaction
    PRIORITY_FEE_GWEI: int = 50   # Priority fee for EIP-1559
    
    # Profit thresholds (in MATIC wei)
    MIN_PROFIT_WEI: int = 1_000_000_000_000_000  # 0.001 MATIC minimum
    PROFIT_TIP_PERCENT: float = 10.0  # 10% of profit goes to validator tip
    
    # ==========================================================================
    # CONTRACT ADDRESSES (Will be updated after deployment)
    # ==========================================================================
    GODFLASH_CONTRACT: str = "0x0000000000000000000000000000000000000000"
    
    # ==========================================================================
    # LOGGING CONFIGURATION
    # ==========================================================================
    LOG_LEVEL: str = "INFO"
    LOG_TO_FILE: bool = True
    LOG_FILE: str = "mev_bot.log"
    
    # ==========================================================================
    # BLACKLIST (Auto-populated by honeypot detector)
    # ==========================================================================
    TOKEN_BLACKLIST: set = None
    
    def __post_init__(self):
        if self.TOKEN_BLACKLIST is None:
            self.TOKEN_BLACKLIST = set()
        if self.RPC_URLS is None:
            self.RPC_URLS = [
                "https://polygon-rpc.com",
                "https://rpc.ankr.com/polygon",
                "https://polygon.llamarpc.com",
                "https://poly-rpc.gateway.pokt.network",
                "https://polygon-bor.publicnode.com",
                "https://polygon.drpc.org",
                "https://polygon.meowrpc.com",
                "https://polygon.rpc.blxrbdn.com",
            ]
        if self.DEX_CONFIG is None:
            self.DEX_CONFIG = {
                "uniswap_v3": {
                    "factory": "0x1F98431c8aD98523631AE4a59f267346ea31F984",
                    "quoter": "0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6",
                    "router": "0xE592427A0AEce92De3Edee1F18E0157C05861564",
                    "fee_tiers": [500, 3000, 10000],
                },
                "quickswap_v3": {
                    "factory": "0x411b0fAcC3E93eF5F87A3B6bd58198AfB41A80cf",
                    "quoter": "0xa15F0D737ceB8E70ae1e47C3575FC656D289C5bE",
                    "router": "0xf5b509bB0909a69B1c207E495f687a596C168E12",
                    "fee_tiers": [500, 3000, 10000],
                },
                "sushiswap_v3": {
                    "factory": "0x917933899c6a5F8E37F31E19f92CdBFF7e8FF0e2",
                    "quoter": "0x64e8802FE490fa7Cc61d3463958199161E60814f",
                    "router": "0x2E6cd2d30aa43f40aa81619ff4b6E0a41479B13F",
                    "fee_tiers": [500, 3000, 10000],
                },
            }


# Global config instance
config = Config()


# =============================================================================
# ABI DEFINITIONS
# =============================================================================

UNISWAP_V3_FACTORY_ABI = [
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True, "internalType": "address", "name": "token0", "type": "address"},
            {"indexed": True, "internalType": "address", "name": "token1", "type": "address"},
            {"indexed": True, "internalType": "uint24", "name": "fee", "type": "uint24"},
            {"indexed": False, "internalType": "int24", "name": "tickSpacing", "type": "int24"},
            {"indexed": False, "internalType": "address", "name": "pool", "type": "address"}
        ],
        "name": "PoolCreated",
        "type": "event"
    },
    {
        "inputs": [
            {"internalType": "address", "name": "tokenA", "type": "address"},
            {"internalType": "address", "name": "tokenB", "type": "address"},
            {"internalType": "uint24", "name": "fee", "type": "uint24"}
        ],
        "name": "getPool",
        "outputs": [{"internalType": "address", "name": "pool", "type": "address"}],
        "stateMutability": "view",
        "type": "function"
    }
]

UNISWAP_V3_POOL_ABI = [
    {
        "inputs": [],
        "name": "slot0",
        "outputs": [
            {"internalType": "uint160", "name": "sqrtPriceX96", "type": "uint160"},
            {"internalType": "int24", "name": "tick", "type": "int24"},
            {"internalType": "uint16", "name": "observationIndex", "type": "uint16"},
            {"internalType": "uint16", "name": "observationCardinality", "type": "uint16"},
            {"internalType": "uint16", "name": "observationCardinalityNext", "type": "uint16"},
            {"internalType": "uint8", "name": "feeProtocol", "type": "uint8"},
            {"internalType": "bool", "name": "unlocked", "type": "bool"}
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "liquidity",
        "outputs": [{"internalType": "uint128", "name": "", "type": "uint128"}],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "token0",
        "outputs": [{"internalType": "address", "name": "", "type": "address"}],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "token1",
        "outputs": [{"internalType": "address", "name": "", "type": "address"}],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "fee",
        "outputs": [{"internalType": "uint24", "name": "", "type": "uint24"}],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "bool", "name": "zeroForOne", "type": "bool"},
            {"internalType": "int256", "name": "amountSpecified", "type": "int256"},
            {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"},
            {"internalType": "bytes", "name": "data", "type": "bytes"}
        ],
        "name": "swap",
        "outputs": [
            {"internalType": "int256", "name": "amount0", "type": "int256"},
            {"internalType": "int256", "name": "amount1", "type": "int256"}
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    }
]

ERC20_ABI = [
    {
        "constant": True,
        "inputs": [],
        "name": "name",
        "outputs": [{"name": "", "type": "string"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "symbol",
        "outputs": [{"name": "", "type": "string"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "decimals",
        "outputs": [{"name": "", "type": "uint8"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [
            {"name": "_owner", "type": "address"},
            {"name": "_spender", "type": "address"}
        ],
        "name": "allowance",
        "outputs": [{"name": "", "type": "uint256"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": False,
        "inputs": [
            {"name": "_spender", "type": "address"},
            {"name": "_value", "type": "uint256"}
        ],
        "name": "approve",
        "outputs": [{"name": "", "type": "bool"}],
        "payable": False,
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "constant": False,
        "inputs": [
            {"name": "_to", "type": "address"},
            {"name": "_value", "type": "uint256"}
        ],
        "name": "transfer",
        "outputs": [{"name": "", "type": "bool"}],
        "payable": False,
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "constant": False,
        "inputs": [
            {"name": "_from", "type": "address"},
            {"name": "_to", "type": "address"},
            {"name": "_value", "type": "uint256"}
        ],
        "name": "transferFrom",
        "outputs": [{"name": "", "type": "bool"}],
        "payable": False,
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True, "name": "owner", "type": "address"},
            {"indexed": True, "name": "spender", "type": "address"},
            {"indexed": False, "name": "value", "type": "uint256"}
        ],
        "name": "Approval",
        "type": "event"
    },
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True, "name": "from", "type": "address"},
            {"indexed": True, "name": "to", "type": "address"},
            {"indexed": False, "name": "value", "type": "uint256"}
        ],
        "name": "Transfer",
        "type": "event"
    }
]

MULTICALL3_ABI = [
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "address", "name": "target", "type": "address"},
                    {"internalType": "bool", "name": "allowFailure", "type": "bool"},
                    {"internalType": "bytes", "name": "callData", "type": "bytes"}
                ],
                "internalType": "struct Multicall3.Call3[]",
                "name": "calls",
                "type": "tuple[]"
            }
        ],
        "name": "aggregate3",
        "outputs": [
            {
                "components": [
                    {"internalType": "bool", "name": "success", "type": "bool"},
                    {"internalType": "bytes", "name": "returnData", "type": "bytes"}
                ],
                "internalType": "struct Multicall3.Result[]",
                "name": "returnData",
                "type": "tuple[]"
            }
        ],
        "stateMutability": "payable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "address", "name": "target", "type": "address"},
                    {"internalType": "bytes", "name": "callData", "type": "bytes"}
                ],
                "internalType": "struct Multicall3.Call[]",
                "name": "calls",
                "type": "tuple[]"
            }
        ],
        "name": "aggregate",
        "outputs": [
            {"internalType": "uint256", "name": "blockNumber", "type": "uint256"},
            {"internalType": "bytes[]", "name": "returnData", "type": "bytes[]"}
        ],
        "stateMutability": "payable",
        "type": "function"
    }
]

GODFLASH_ABI = [
    {
        "inputs": [
            {"internalType": "address[]", "name": "pools", "type": "address[]"},
            {"internalType": "bool[]", "name": "zeroForOnes", "type": "bool[]"},
            {"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"},
            {"internalType": "uint160[]", "name": "sqrtPriceLimitX96s", "type": "uint160[]"},
            {"internalType": "uint256", "name": "minProfit", "type": "uint256"},
            {"internalType": "uint256", "name": "tipBps", "type": "uint256"}
        ],
        "name": "executeFlashSwap",
        "outputs": [{"internalType": "uint256", "name": "profit", "type": "uint256"}],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "int256", "name": "amount0Delta", "type": "int256"},
            {"internalType": "int256", "name": "amount1Delta", "type": "int256"},
            {"internalType": "bytes", "name": "data", "type": "bytes"}
        ],
        "name": "uniswapV3SwapCallback",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "owner",
        "outputs": [{"internalType": "address", "name": "", "type": "address"}],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "withdraw",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    }
]
