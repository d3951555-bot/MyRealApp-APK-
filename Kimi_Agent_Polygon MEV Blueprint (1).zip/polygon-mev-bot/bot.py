"""
Polygon God-Mode MEV Bot - Main Engine
AsyncIO-powered arbitrage execution with FastLane bundles
"""

import asyncio
import logging
import time
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass
from decimal import Decimal
import aiohttp
import json
from web3 import Web3, AsyncWeb3
from web3.middleware import geth_poa_middleware
from eth_account import Account
from eth_abi import encode, decode
import random

from config import (
    config,
    GODFLASH_ABI,
    UNISWAP_V3_POOL_ABI,
    MULTICALL3_ABI,
    ERC20_ABI
)
from scanner import DexScanner, ArbitragePath, TokenPair

# Configure logging
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(config.LOG_FILE) if config.LOG_TO_FILE else logging.NullHandler()
    ]
)
logger = logging.getLogger(__name__)


@dataclass
class ExecutionResult:
    """Result of an arbitrage execution"""
    success: bool
    tx_hash: Optional[str] = None
    profit: float = 0.0
    gas_used: int = 0
    gas_cost: float = 0.0
    net_profit: float = 0.0
    error: Optional[str] = None
    simulation_only: bool = True


class RPCRotator:
    """
    Async RPC Rotator to avoid rate limits
    Cycles through 5+ public RPCs for each request
    """
    
    def __init__(self, rpc_urls: List[str]):
        self.rpc_urls = rpc_urls
        self.current_index = 0
        self.failed_counts: Dict[str, int] = {url: 0 for url in rpc_urls}
        self.last_used: Dict[str, float] = {url: 0 for url in rpc_urls}
        self._lock = asyncio.Lock()
        
    async def get_next_rpc(self) -> str:
        """Get next RPC URL with rotation"""
        async with self._lock:
            # Find least recently used RPC that hasn't failed too much
            available = [
                url for url in self.rpc_urls 
                if self.failed_counts[url] < 5
            ]
            
            if not available:
                # Reset all failed counts if all failed
                logger.warning("All RPCs failed, resetting counters")
                for url in self.rpc_urls:
                    self.failed_counts[url] = 0
                available = self.rpc_urls
            
            # Sort by last used time
            available.sort(key=lambda x: self.last_used[x])
            
            selected = available[0]
            self.last_used[selected] = time.time()
            
            return selected
    
    async def mark_failed(self, rpc_url: str):
        """Mark an RPC as failed"""
        async with self._lock:
            self.failed_counts[rpc_url] += 1
            logger.warning(f"RPC {rpc_url[:30]}... failed ({self.failed_counts[rpc_url]} times)")
    
    async def mark_success(self, rpc_url: str):
        """Mark an RPC as successful"""
        async with self._lock:
            self.failed_counts[rpc_url] = max(0, self.failed_counts[rpc_url] - 1)


class FastLaneBundle:
    """
    FastLane Protocol Bundle Manager
    Submits private transactions to avoid MEV competition
    """
    
    def __init__(self, relay_url: str = None):
        self.relay_url = relay_url or config.FASTLANE_RELAY_URL
        self.session: Optional[aiohttp.ClientSession] = None
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30)
        )
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def submit_bundle(
        self,
        signed_txs: List[str],
        block_target: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Submit a bundle of transactions to FastLane
        
        Args:
            signed_txs: List of signed transaction hex strings
            block_target: Target block number (optional)
            
        Returns:
            Bundle submission result
        """
        if not self.session:
            raise RuntimeError("FastLane session not initialized")
        
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "eth_sendBundle",
            "params": [{
                "txs": signed_txs,
                "blockNumber": hex(block_target) if block_target else None,
                "minTimestamp": 0,
                "maxTimestamp": 0,
                "revertingTxHashes": []
            }]
        }
        
        try:
            async with self.session.post(
                self.relay_url,
                json=payload,
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    logger.info(f"Bundle submitted: {result}")
                    return result
                else:
                    error_text = await response.text()
                    logger.error(f"Bundle submission failed: {error_text}")
                    return {"error": error_text}
                    
        except Exception as e:
            logger.error(f"FastLane bundle error: {e}")
            return {"error": str(e)}
    
    async def simulate_bundle(
        self,
        signed_txs: List[str],
        block_number: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Simulate a bundle before submission
        
        Args:
            signed_txs: List of signed transaction hex strings
            block_number: Block number to simulate at
            
        Returns:
            Simulation result with profit/loss
        """
        if not self.session:
            raise RuntimeError("FastLane session not initialized")
        
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "eth_callBundle",
            "params": [{
                "txs": signed_txs,
                "blockNumber": hex(block_number) if block_number else None,
                "stateBlockNumber": "latest",
                "timestamp": int(time.time())
            }]
        }
        
        try:
            async with self.session.post(
                self.relay_url,
                json=payload,
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    return result
                else:
                    error_text = await response.text()
                    logger.error(f"Bundle simulation failed: {error_text}")
                    return {"error": error_text}
                    
        except Exception as e:
            logger.error(f"FastLane simulation error: {e}")
            return {"error": str(e)}


class Multicall3Batch:
    """
    Batch query prices using Multicall3
    Queries 200 pairs in < 100ms
    """
    
    def __init__(self, w3: Web3, multicall_address: str):
        self.w3 = w3
        self.multicall = w3.eth.contract(
            address=Web3.to_checksum_address(multicall_address),
            abi=MULTICALL3_ABI
        )
        
    def batch_quote_exact_input_single(
        self,
        quoter_address: str,
        token_in: str,
        token_out: str,
        fee: int,
        amount_in: int,
        sqrt_price_limit_x96: int
    ) -> bytes:
        """Build call data for quoter"""
        # QuoterV2 interface
        selector = bytes.fromhex("c6a5026a")  # quoteExactInputSingle
        
        # Encode parameters
        params = encode(
            ['address', 'address', 'uint24', 'uint256', 'uint160'],
            [token_in, token_out, fee, amount_in, sqrt_price_limit_x96]
        )
        
        return selector + params
    
    async def batch_fetch_prices(
        self,
        pairs: List[TokenPair],
        amount_in: int = 1000000000000000000  # 1 token
    ) -> Dict[str, Dict[str, Any]]:
        """
        Fetch prices for multiple pairs in a single multicall
        
        Args:
            pairs: List of TokenPair objects
            amount_in: Amount to quote (default 1 token)
            
        Returns:
            Dictionary of pool_address -> price data
        """
        if not pairs:
            return {}
        
        calls = []
        for pair in pairs:
            pool_contract = self.w3.eth.contract(
                address=Web3.to_checksum_address(pair.pool_address),
                abi=UNISWAP_V3_POOL_ABI
            )
            
            # Build slot0 call
            calls.append({
                'target': pair.pool_address,
                'allowFailure': True,
                'callData': pool_contract.functions.slot0().build_transaction({'gas': 0})['data']
            })
        
        try:
            start_time = time.time()
            results = self.multicall.functions.aggregate3(calls).call()
            elapsed = (time.time() - start_time) * 1000
            
            logger.debug(f"Multicall completed in {elapsed:.2f}ms for {len(pairs)} pairs")
            
            prices = {}
            for pair, result in zip(pairs, results):
                if result[0]:  # success
                    try:
                        decoded = decode(
                            ['uint160', 'int24', 'uint16', 'uint16', 'uint16', 'uint8', 'bool'],
                            result[1]
                        )
                        sqrt_price_x96 = decoded[0]
                        
                        # Calculate price
                        price = (sqrt_price_x96 / (2 ** 96)) ** 2
                        
                        prices[pair.pool_address] = {
                            'sqrtPriceX96': sqrt_price_x96,
                            'price': price,
                            'tick': decoded[1],
                            'success': True
                        }
                    except Exception as e:
                        logger.debug(f"Failed to decode price for {pair.pool_address}: {e}")
                        prices[pair.pool_address] = {'success': False, 'error': str(e)}
                else:
                    prices[pair.pool_address] = {'success': False, 'error': 'Call failed'}
            
            return prices
            
        except Exception as e:
            logger.error(f"Multicall failed: {e}")
            return {}


class MEVBot:
    """
    Main MEV Bot Engine
    AsyncIO-powered with RPC rotation and FastLane bundles
    """
    
    def __init__(self):
        self.rpc_rotator = RPCRotator(config.RPC_URLS)
        self.w3: Optional[Web3] = None
        self.scanner: Optional[DexScanner] = None
        self.fastlane: Optional[FastLaneBundle] = None
        self.multicall: Optional[Multicall3Batch] = None
        self.godflash_contract = None
        self.account = None
        self.running = False
        self.stats = {
            'scans': 0,
            'opportunities_found': 0,
            'simulations_run': 0,
            'bundles_sent': 0,
            'successful_trades': 0,
            'total_profit': 0.0,
            'total_gas_cost': 0.0
        }
        
    async def initialize(self):
        """Initialize the bot"""
        logger.info("Initializing MEV Bot...")
        
        # Initialize Web3 with first RPC
        rpc_url = await self.rpc_rotator.get_next_rpc()
        self.w3 = Web3(Web3.HTTPProvider(rpc_url))
        
        # Add POA middleware for Polygon
        self.w3.middleware_onion.inject(geth_poa_middleware, layer=0)
        
        if not self.w3.is_connected():
            raise ConnectionError("Failed to connect to initial RPC")
        
        logger.info(f"Connected to Polygon. Block: {self.w3.eth.block_number}")
        
        # Initialize account
        if config.PRIVATE_KEY and config.PRIVATE_KEY != "0xYOUR_PRIVATE_KEY_HERE":
            self.account = Account.from_key(config.PRIVATE_KEY)
            logger.info(f"Account loaded: {self.account.address}")
        else:
            logger.warning("No private key configured - running in simulation mode only")
        
        # Initialize scanner
        self.scanner = DexScanner(self.w3)
        
        # Initialize FastLane
        if config.FASTLANE_ENABLED:
            self.fastlane = FastLaneBundle()
            logger.info("FastLane bundle manager initialized")
        
        # Initialize Multicall3
        self.multicall = Multicall3Batch(self.w3, config.MULTICALL3_ADDRESS)
        
        # Initialize GodFlash contract
        if config.GODFLASH_CONTRACT != "0x0000000000000000000000000000000000000000":
            self.godflash_contract = self.w3.eth.contract(
                address=Web3.to_checksum_address(config.GODFLASH_CONTRACT),
                abi=GODFLASH_ABI
            )
            logger.info(f"GodFlash contract loaded: {config.GODFLASH_CONTRACT}")
        
        logger.info("MEV Bot initialized successfully")
    
    async def rotate_rpc(self) -> Web3:
        """Rotate to a new RPC"""
        new_rpc = await self.rpc_rotator.get_next_rpc()
        
        try:
            new_w3 = Web3(Web3.HTTPProvider(new_rpc))
            new_w3.middleware_onion.inject(geth_poa_middleware, layer=0)
            
            if new_w3.is_connected():
                self.w3 = new_w3
                # Re-initialize dependent components
                self.scanner = DexScanner(self.w3)
                self.multicall = Multicall3Batch(self.w3, config.MULTICALL3_ADDRESS)
                if self.godflash_contract:
                    self.godflash_contract = self.w3.eth.contract(
                        address=Web3.to_checksum_address(config.GODFLASH_CONTRACT),
                        abi=GODFLASH_ABI
                    )
                logger.debug(f"Rotated to RPC: {new_rpc[:30]}...")
                return self.w3
            else:
                await self.rpc_rotator.mark_failed(new_rpc)
                return await self.rotate_rpc()
                
        except Exception as e:
            logger.error(f"RPC rotation failed: {e}")
            await self.rpc_rotator.mark_failed(new_rpc)
            return await self.rotate_rpc()
    
    async def simulate_arbitrage(
        self,
        path: ArbitragePath
    ) -> ExecutionResult:
        """
        Simulate an arbitrage path using eth_call
        
        Args:
            path: ArbitragePath to simulate
            
        Returns:
            ExecutionResult with simulation outcome
        """
        if not self.godflash_contract:
            return ExecutionResult(
                success=False,
                error="GodFlash contract not deployed",
                simulation_only=True
            )
        
        try:
            # Build transaction
            tx = self.godflash_contract.functions.executeFlashSwap(
                path.pools,
                path.zero_for_ones,
                path.amounts,
                [0] * len(path.pools),  # No price limits
                int(config.MIN_PROFIT_WEI),
                int(config.PROFIT_TIP_PERCENT * 100)  # Convert to bps
            ).build_transaction({
                'from': self.account.address if self.account else config.WALLET_ADDRESS,
                'gas': config.MAX_GAS_LIMIT,
                'maxFeePerGas': self.w3.to_wei(config.MAX_GAS_PRICE_GWEI, 'gwei'),
                'maxPriorityFeePerGas': self.w3.to_wei(config.PRIORITY_FEE_GWEI, 'gwei'),
                'nonce': self.w3.eth.get_transaction_count(
                    self.account.address if self.account else config.WALLET_ADDRESS
                ),
                'chainId': config.CHAIN_ID
            })
            
            # Simulate with eth_call
            start_time = time.time()
            result = self.w3.eth.call(tx)
            elapsed = (time.time() - start_time) * 1000
            
            self.stats['simulations_run'] += 1
            
            # Decode result (profit)
            profit = decode(['uint256'], result)[0]
            profit_eth = self.w3.from_wei(profit, 'ether')
            
            logger.info(f"Simulation successful: {profit_eth:.6f} MATIC profit ({elapsed:.2f}ms)")
            
            return ExecutionResult(
                success=True,
                profit=float(profit_eth),
                simulation_only=True
            )
            
        except Exception as e:
            error_str = str(e)
            # Check for specific revert reasons
            if "NoProfit" in error_str:
                return ExecutionResult(
                    success=False,
                    error="No profit in simulation",
                    simulation_only=True
                )
            elif "InvalidPath" in error_str:
                return ExecutionResult(
                    success=False,
                    error="Invalid arbitrage path",
                    simulation_only=True
                )
            else:
                logger.debug(f"Simulation failed: {error_str[:100]}")
                return ExecutionResult(
                    success=False,
                    error=error_str[:200],
                    simulation_only=True
                )
    
    async def execute_arbitrage(
        self,
        path: ArbitragePath
    ) -> ExecutionResult:
        """
        Execute an arbitrage via FastLane bundle
        
        Args:
            path: ArbitragePath to execute
            
        Returns:
            ExecutionResult with execution outcome
        """
        # If in simulation mode, just simulate
        if config.SIMULATION_MODE:
            return await self.simulate_arbitrage(path)
        
        if not self.account:
            return ExecutionResult(
                success=False,
                error="No private key configured",
                simulation_only=True
            )
        
        if not self.godflash_contract:
            return ExecutionResult(
                success=False,
                error="GodFlash contract not deployed",
                simulation_only=True
            )
        
        try:
            # Build transaction
            tx = self.godflash_contract.functions.executeFlashSwap(
                path.pools,
                path.zero_for_ones,
                path.amounts,
                [0] * len(path.pools),
                int(config.MIN_PROFIT_WEI),
                int(config.PROFIT_TIP_PERCENT * 100)
            ).build_transaction({
                'from': self.account.address,
                'gas': config.MAX_GAS_LIMIT,
                'maxFeePerGas': self.w3.to_wei(config.MAX_GAS_PRICE_GWEI, 'gwei'),
                'maxPriorityFeePerGas': self.w3.to_wei(config.PRIORITY_FEE_GWEI, 'gwei'),
                'nonce': self.w3.eth.get_transaction_count(self.account.address),
                'chainId': config.CHAIN_ID
            })
            
            # Sign transaction
            signed_tx = self.account.sign_transaction(tx)
            
            # Submit via FastLane
            if self.fastlane and config.FASTLANE_ENABLED:
                async with self.fastlane:
                    # Simulate first
                    sim_result = await self.fastlane.simulate_bundle(
                        [signed_tx.rawTransaction.hex()]
                    )
                    
                    if 'error' in sim_result:
                        logger.warning(f"Bundle simulation failed: {sim_result['error']}")
                        return ExecutionResult(
                            success=False,
                            error=f"Simulation failed: {sim_result['error']}",
                            simulation_only=False
                        )
                    
                    # Submit bundle
                    bundle_result = await self.fastlane.submit_bundle(
                        [signed_tx.rawTransaction.hex()]
                    )
                    
                    self.stats['bundles_sent'] += 1
                    
                    if 'error' not in bundle_result:
                        logger.info(f"Bundle submitted: {bundle_result}")
                        return ExecutionResult(
                            success=True,
                            tx_hash=bundle_result.get('result', {}).get('bundleHash'),
                            simulation_only=False
                        )
                    else:
                        return ExecutionResult(
                            success=False,
                            error=bundle_result['error'],
                            simulation_only=False
                        )
            else:
                # Fallback to direct send
                tx_hash = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction)
                logger.info(f"Transaction sent: {tx_hash.hex()}")
                
                return ExecutionResult(
                    success=True,
                    tx_hash=tx_hash.hex(),
                    simulation_only=False
                )
                
        except Exception as e:
            logger.error(f"Execution failed: {e}")
            return ExecutionResult(
                success=False,
                error=str(e)[:200],
                simulation_only=False
            )
    
    async def scan_cycle(self):
        """Single scan cycle"""
        try:
            # Rotate RPC for this scan
            await self.rotate_rpc()
            
            # Run full scan
            pairs = await self.scanner.full_scan()
            self.stats['scans'] += 1
            
            # Get watchlist
            watchlist = await self.scanner.get_watchlist()
            
            if not watchlist:
                logger.debug("No pairs in watchlist")
                return
            
            # Batch fetch prices using Multicall3
            prices = await self.multicall.batch_fetch_prices(watchlist)
            
            # Find opportunities
            opportunities = []
            for pair in watchlist:
                price_data = prices.get(pair.pool_address, {})
                if price_data.get('success'):
                    # Calculate potential arbitrage paths
                    paths = await self.scanner.calculate_arbitrage_paths(
                        pair, 
                        self.scanner.pairs
                    )
                    
                    for path in paths:
                        # Simulate each path
                        result = await self.simulate_arbitrage(path)
                        
                        if result.success and result.profit > 0:
                            path.expected_profit = result.profit
                            opportunities.append((path, result))
            
            # Sort by profit
            opportunities.sort(key=lambda x: x[0].expected_profit, reverse=True)
            
            if opportunities:
                self.stats['opportunities_found'] += len(opportunities)
                logger.info(f"Found {len(opportunities)} profitable opportunities")
                
                # Log top 3
                for i, (path, result) in enumerate(opportunities[:3]):
                    logger.info(f"  {i+1}. {path.path_type}: {result.profit:.6f} MATIC")
                
                # Execute best opportunity if not in simulation mode
                if not config.SIMULATION_MODE and opportunities:
                    best_path, best_result = opportunities[0]
                    logger.info(f"Executing best opportunity: {best_result.profit:.6f} MATIC")
                    
                    exec_result = await self.execute_arbitrage(best_path)
                    
                    if exec_result.success:
                        self.stats['successful_trades'] += 1
                        self.stats['total_profit'] += exec_result.profit
                        logger.info(f"Trade executed successfully!")
                    else:
                        logger.warning(f"Trade failed: {exec_result.error}")
            
        except Exception as e:
            logger.error(f"Scan cycle error: {e}")
    
    async def run(self):
        """Main bot loop"""
        logger.info("=" * 60)
        logger.info("POLYGON GOD-MODE MEV BOT STARTED")
        logger.info(f"Simulation Mode: {config.SIMULATION_MODE}")
        logger.info(f"FastLane Enabled: {config.FASTLANE_ENABLED}")
        logger.info(f"Scan Interval: {config.SCAN_INTERVAL}s")
        logger.info("=" * 60)
        
        self.running = True
        
        # Initial scan
        await self.scan_cycle()
        
        while self.running:
            try:
                await self.scan_cycle()
                
                # Print stats periodically
                if self.stats['scans'] % 10 == 0:
                    logger.info("=" * 60)
                    logger.info("BOT STATISTICS:")
                    logger.info(f"  Scans: {self.stats['scans']}")
                    logger.info(f"  Opportunities Found: {self.stats['opportunities_found']}")
                    logger.info(f"  Simulations Run: {self.stats['simulations_run']}")
                    logger.info(f"  Bundles Sent: {self.stats['bundles_sent']}")
                    logger.info(f"  Successful Trades: {self.stats['successful_trades']}")
                    logger.info(f"  Total Profit: {self.stats['total_profit']:.6f} MATIC")
                    logger.info("=" * 60)
                
                # Wait for next scan
                await asyncio.sleep(config.SCAN_INTERVAL)
                
            except Exception as e:
                logger.error(f"Main loop error: {e}")
                await asyncio.sleep(1)
    
    def stop(self):
        """Stop the bot"""
        logger.info("Stopping MEV Bot...")
        self.running = False


# =============================================================================
# STANDALONE TEST
# =============================================================================

async def test_bot():
    """Test the bot functionality"""
    bot = MEVBot()
    
    try:
        await bot.initialize()
        
        # Run for a few cycles
        logger.info("Running test cycles...")
        for i in range(3):
            logger.info(f"\n--- Cycle {i+1} ---")
            await bot.scan_cycle()
            await asyncio.sleep(2)
        
        logger.info("\nTest complete!")
        logger.info(f"Stats: {bot.stats}")
        
    except Exception as e:
        logger.error(f"Test failed: {e}")
        raise
    finally:
        bot.stop()


if __name__ == "__main__":
    # Check if running in simulation mode
    if config.SIMULATION_MODE:
        logger.info("Running in SIMULATION MODE - No real transactions will be sent")
    
    try:
        asyncio.run(test_bot())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
