// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

// =============================================================================
// GODFLASH - Polygon MEV Flash Swap Engine
// $5 Budget Optimized - Gas Efficiency First
// =============================================================================
// Features:
// - Multi-hop Flash Swaps (Uniswap V3 callback pattern)
// - EIP-1153 Transient Storage for gas optimization
// - Atomic reverts on zero/negative profit
// - Validator tip distribution
// - Zero-approve token transfers
// =============================================================================

// =============================================================================
// EIP-1153 TRANSIENT STORAGE LIBRARY
// Using tstore/tload for reentrancy guards and temporary variables
// Gas cost: 100 gas vs 20000 gas for SSTORE
// =============================================================================
library TransientStorage {
    // Slot constants for transient storage
    bytes32 constant REENTRANCY_LOCK_SLOT = bytes32(uint256(keccak256("godflash.reentrancy")) - 1);
    bytes32 constant INITIAL_BALANCE_SLOT = bytes32(uint256(keccak256("godflash.initial_balance")) - 1);
    bytes32 constant CALLBACK_INDEX_SLOT = bytes32(uint256(keccak256("godflash.callback_index")) - 1);
    bytes32 constant PROFIT_SLOT = bytes32(uint256(keccak256("godflash.profit")) - 1);
    
    // Reentrancy lock
    function lock() internal {
        assembly {
            tstore(REENTRANCY_LOCK_SLOT, 1)
        }
    }
    
    function unlock() internal {
        assembly {
            tstore(REENTRANCY_LOCK_SLOT, 0)
        }
    }
    
    function isLocked() internal view returns (bool) {
        bool locked;
        assembly {
            locked := tload(REENTRANCY_LOCK_SLOT)
        }
        return locked;
    }
    
    // Initial balance tracking
    function setInitialBalance(uint256 balance) internal {
        assembly {
            tstore(INITIAL_BALANCE_SLOT, balance)
        }
    }
    
    function getInitialBalance() internal view returns (uint256) {
        uint256 balance;
        assembly {
            balance := tload(INITIAL_BALANCE_SLOT)
        }
        return balance;
    }
    
    // Callback index for multi-hop
    function setCallbackIndex(uint256 index) internal {
        assembly {
            tstore(CALLBACK_INDEX_SLOT, index)
        }
    }
    
    function getCallbackIndex() internal view returns (uint256) {
        uint256 index;
        assembly {
            index := tload(CALLBACK_INDEX_SLOT)
        }
        return index;
    }
    
    function incrementCallbackIndex() internal {
        assembly {
            let current := tload(CALLBACK_INDEX_SLOT)
            tstore(CALLBACK_INDEX_SLOT, add(current, 1))
        }
    }
    
    // Profit tracking
    function setProfit(uint256 profit) internal {
        assembly {
            tstore(PROFIT_SLOT, profit)
        }
    }
    
    function getProfit() internal view returns (uint256) {
        uint256 profit;
        assembly {
            profit := tload(PROFIT_SLOT)
        }
        return profit;
    }
}

// =============================================================================
// INTERFACES
// =============================================================================

interface IUniswapV3Pool {
    function swap(
        address recipient,
        bool zeroForOne,
        int256 amountSpecified,
        uint160 sqrtPriceLimitX96,
        bytes calldata data
    ) external returns (int256 amount0, int256 amount1);
    
    function token0() external view returns (address);
    function token1() external view returns (address);
    function fee() external view returns (uint24);
}

interface IERC20 {
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function decimals() external view returns (uint8);
}

interface IWETH is IERC20 {
    function deposit() external payable;
    function withdraw(uint256 amount) external;
}

// =============================================================================
// GODFLASH CONTRACT
// =============================================================================

contract GodFlash {
    using TransientStorage for *;
    
    // ==========================================================================
    // ERRORS (Custom errors save gas vs require strings)
    // ==========================================================================
    error ReentrancyGuard();
    error InvalidPath();
    error InvalidPool();
    error CallbackFailed();
    error NoProfit();
    error InsufficientBalance();
    error Unauthorized();
    error TransferFailed();
    error InvalidAmount();
    
    // ==========================================================================
    // EVENTS
    // ==========================================================================
    event FlashSwapExecuted(
        address indexed executor,
        uint256 profit,
        uint256 tip,
        uint256 gasUsed,
        uint256 pathLength
    );
    
    event OpportunityDetected(
        address[] pools,
        uint256 expectedProfit,
        string pathType
    );
    
    // ==========================================================================
    // CONSTANTS
    // ==========================================================================
    address public immutable owner;
    address public immutable WMATIC;
    
    // Minimum profit threshold (in wei)
    uint256 public constant MIN_PROFIT = 0.001 ether; // 0.001 MATIC
    
    // Maximum path length
    uint256 public constant MAX_PATH_LENGTH = 5;
    
    // Uniswap V3 callback selector
    bytes4 private constant UNISWAP_V3_SWAP_CALLBACK_SELECTOR = 
        bytes4(keccak256("uniswapV3SwapCallback(int256,int256,bytes)"));
    
    // ==========================================================================
    // STATE VARIABLES (Minimal - use transient storage where possible)
    // ==========================================================================
    
    // Flash swap data structure (passed through callback)
    struct FlashData {
        address[] pools;           // Pool addresses
        address[] tokens;          // Token addresses (tokens[0] = input)
        bool[] zeroForOnes;        // Direction for each swap
        uint256[] amounts;         // Amounts for each swap
        uint256 minProfit;         // Minimum profit required
        uint256 tipBps;            // Tip to validator (basis points)
        uint256 initialBalance;    // Starting balance
    }
    
    // Store current flash data (cleared after each execution)
    FlashData private currentFlashData;
    
    // ==========================================================================
    // MODIFIERS
    // ==========================================================================
    
    modifier onlyOwner() {
        if (msg.sender != owner) revert Unauthorized();
        _;
    }
    
    modifier nonReentrant() {
        if (TransientStorage.isLocked()) revert ReentrancyGuard();
        TransientStorage.lock();
        _;
        TransientStorage.unlock();
    }
    
    // ==========================================================================
    // CONSTRUCTOR
    // ==========================================================================
    
    constructor(address _wmatic) {
        owner = msg.sender;
        WMATIC = _wmatic;
    }
    
    // ==========================================================================
    // RECEIVE & FALLBACK
    // ==========================================================================
    
    receive() external payable {}
    
    fallback() external payable {
        // Accept ETH from WMATIC unwrap
    }
    
    // ==========================================================================
    // MAIN FLASH SWAP EXECUTION
    // ==========================================================================
    
    /**
     * @notice Execute a multi-hop flash swap arbitrage
     * @param pools Array of pool addresses to swap through
     * @param zeroForOnes Array of swap directions
     * @param amounts Array of swap amounts
     * @param sqrtPriceLimitX96s Array of price limits (0 for no limit)
     * @param minProfit Minimum profit required (reverts if not met)
     * @param tipBps Tip percentage to validator (basis points, e.g., 100 = 1%)
     * @return profit The actual profit achieved
     */
    function executeFlashSwap(
        address[] calldata pools,
        bool[] calldata zeroForOnes,
        uint256[] calldata amounts,
        uint160[] calldata sqrtPriceLimitX96s,
        uint256 minProfit,
        uint256 tipBps
    ) external nonReentrant returns (uint256 profit) {
        // Validate inputs
        uint256 pathLength = pools.length;
        if (pathLength == 0 || pathLength > MAX_PATH_LENGTH) revert InvalidPath();
        if (pathLength != zeroForOnes.length || pathLength != amounts.length) revert InvalidPath();
        
        // Build token path
        address[] memory tokens = new address[](pathLength + 1);
        
        // Get tokens from first pool
        IUniswapV3Pool firstPool = IUniswapV3Pool(pools[0]);
        tokens[0] = zeroForOnes[0] ? firstPool.token0() : firstPool.token1();
        tokens[1] = zeroForOnes[0] ? firstPool.token1() : firstPool.token0();
        
        // Build rest of token path
        for (uint256 i = 1; i < pathLength; i++) {
            IUniswapV3Pool pool = IUniswapV3Pool(pools[i]);
            tokens[i + 1] = zeroForOnes[i] ? pool.token1() : pool.token0();
            
            // Validate path continuity
            address expectedInput = zeroForOnes[i] ? pool.token0() : pool.token1();
            if (tokens[i] != expectedInput) revert InvalidPath();
        }
        
        // Must start and end with WMATIC for profit calculation
        if (tokens[0] != WMATIC || tokens[pathLength] != WMATIC) revert InvalidPath();
        
        // Record initial balance using transient storage
        uint256 initialBalance = IERC20(WMATIC).balanceOf(address(this));
        TransientStorage.setInitialBalance(initialBalance);
        
        // Store flash data
        currentFlashData = FlashData({
            pools: pools,
            tokens: tokens,
            zeroForOnes: zeroForOnes,
            amounts: amounts,
            minProfit: minProfit,
            tipBps: tipBps,
            initialBalance: initialBalance
        });
        
        // Reset callback index
        TransientStorage.setCallbackIndex(0);
        
        // Emit opportunity detection
        emit OpportunityDetected(pools, minProfit, pathLength == 1 ? "direct" : "triangular");
        
        // Start the flash swap chain
        _executeSwap(0, sqrtPriceLimitX96s[0]);
        
        // Calculate final profit
        uint256 finalBalance = IERC20(WMATIC).balanceOf(address(this));
        
        // ATOMIC REVERT: If no profit, revert entire transaction
        if (finalBalance <= initialBalance) {
            revert NoProfit();
        }
        
        profit = finalBalance - initialBalance;
        
        // Check minimum profit
        if (profit < minProfit) {
            revert NoProfit();
        }
        
        // Store profit in transient storage for potential future use
        TransientStorage.setProfit(profit);
        
        // Calculate and send validator tip
        uint256 tip = (profit * tipBps) / 10000;
        if (tip > 0) {
            // Convert WMATIC to MATIC for tip
            IWETH(WMATIC).withdraw(tip);
            
            // Send tip to block.coinbase (validator)
            (bool success, ) = block.coinbase.call{value: tip}("");
            // Don't revert on tip failure, just emit event with actual tip
            if (!success) {
                tip = 0;
            }
        }
        
        // Clear flash data
        delete currentFlashData;
        
        emit FlashSwapExecuted(
            msg.sender,
            profit,
            tip,
            gasleft(),
            pathLength
        );
        
        return profit;
    }
    
    // ==========================================================================
    // UNISWAP V3 CALLBACK
    // ==========================================================================
    
    /**
     * @notice Uniswap V3 swap callback
     * @param amount0Delta Amount of token0 owed (positive) or received (negative)
     * @param amount1Delta Amount of token1 owed (positive) or received (negative)
     * @param data Arbitrary data passed through from swap call
     */
    function uniswapV3SwapCallback(
        int256 amount0Delta,
        int256 amount1Delta,
        bytes calldata data
    ) external {
        // Get current callback index
        uint256 callbackIndex = TransientStorage.getCallbackIndex();
        
        // Verify caller is expected pool
        if (msg.sender != currentFlashData.pools[callbackIndex]) {
            revert InvalidPool();
        }
        
        // Determine which token we owe and how much
        bool zeroForOne = currentFlashData.zeroForOnes[callbackIndex];
        int256 amountToPay = zeroForOne ? amount0Delta : amount1Delta;
        
        if (amountToPay <= 0) {
            // We received tokens, no payment needed yet
            revert CallbackFailed();
        }
        
        address tokenIn = currentFlashData.tokens[callbackIndex];
        address tokenOut = currentFlashData.tokens[callbackIndex + 1];
        
        // Check if there's another swap in the chain
        if (callbackIndex + 1 < currentFlashData.pools.length) {
            // More swaps to execute - initiate next flash swap
            TransientStorage.incrementCallbackIndex();
            
            // Get next pool
            address nextPool = currentFlashData.pools[callbackIndex + 1];
            
            // We need to pay tokenIn, but we'll get tokenOut from the next swap
            // For flash swaps, we don't pay now - we cascade through
            
            // Calculate amount for next swap
            uint256 nextAmount = currentFlashData.amounts[callbackIndex + 1];
            
            // Execute next swap (this will trigger another callback)
            IUniswapV3Pool(nextPool).swap(
                address(this),
                currentFlashData.zeroForOnes[callbackIndex + 1],
                int256(nextAmount),
                0, // No price limit for intermediate swaps
                data
            );
            
            // After the chain completes, we should have received enough to pay back
            // The final callback will handle the payment
        }
        
        // Now we need to pay back the owed amount
        // Use direct transfer (no approve needed for self-transfers)
        _transferToken(tokenIn, msg.sender, uint256(amountToPay));
        
        // Increment callback index for next iteration
        TransientStorage.incrementCallbackIndex();
    }
    
    // ==========================================================================
    // INTERNAL FUNCTIONS
    // ==========================================================================
    
    /**
     * @notice Execute a single swap in the chain
     */
    function _executeSwap(uint256 index, uint160 sqrtPriceLimitX96) internal {
        address pool = currentFlashData.pools[index];
        bool zeroForOne = currentFlashData.zeroForOnes[index];
        uint256 amount = currentFlashData.amounts[index];
        
        // Execute swap
        IUniswapV3Pool(pool).swap(
            address(this),
            zeroForOne,
            int256(amount),
            sqrtPriceLimitX96,
            ""
        );
    }
    
    /**
     * @notice Transfer tokens without approval (uses direct transfer)
     * Gas-optimized: No approve call needed
     */
    function _transferToken(address token, address to, uint256 amount) internal {
        // Use low-level call for gas efficiency
        (bool success, bytes memory data) = token.call(
            abi.encodeWithSelector(IERC20.transfer.selector, to, amount)
        );
        
        if (!success || (data.length > 0 && !abi.decode(data, (bool)))) {
            revert TransferFailed();
        }
    }
    
    /**
     * @notice Transfer tokens from without approval check
     * Only use when tokens are already held by this contract
     */
    function _transferTokenFrom(address token, address from, address to, uint256 amount) internal {
        (bool success, bytes memory data) = token.call(
            abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, amount)
        );
        
        if (!success || (data.length > 0 && !abi.decode(data, (bool)))) {
            revert TransferFailed();
        }
    }
    
    // ==========================================================================
    // VIEW FUNCTIONS
    // ==========================================================================
    
    /**
     * @notice Get current WMATIC balance
     */
    function getBalance() external view returns (uint256) {
        return IERC20(WMATIC).balanceOf(address(this));
    }
    
    /**
     * @notice Get token balance
     */
    function getTokenBalance(address token) external view returns (uint256) {
        return IERC20(token).balanceOf(address(this));
    }
    
    // ==========================================================================
    // ADMIN FUNCTIONS
    // ==========================================================================
    
    /**
     * @notice Withdraw all WMATIC to owner
     */
    function withdraw() external onlyOwner {
        uint256 balance = IERC20(WMATIC).balanceOf(address(this));
        if (balance > 0) {
            _transferToken(WMATIC, owner, balance);
        }
    }
    
    /**
     * @notice Withdraw specific token to owner
     */
    function withdrawToken(address token) external onlyOwner {
        uint256 balance = IERC20(token).balanceOf(address(this));
        if (balance > 0) {
            _transferToken(token, owner, balance);
        }
    }
    
    /**
     * @notice Withdraw MATIC to owner
     */
    function withdrawMATIC() external onlyOwner {
        uint256 balance = address(this).balance;
        if (balance > 0) {
            (bool success, ) = owner.call{value: balance}("");
            if (!success) revert TransferFailed();
        }
    }
    
    /**
     * @notice Emergency rescue function
     */
    function emergencyWithdraw(address token) external onlyOwner {
        if (token == address(0)) {
            (bool success, ) = owner.call{value: address(this).balance}("");
            if (!success) revert TransferFailed();
        } else {
            uint256 balance = IERC20(token).balanceOf(address(this));
            if (balance > 0) {
                (bool success, bytes memory data) = token.call(
                    abi.encodeWithSelector(IERC20.transfer.selector, owner, balance)
                );
                if (!success) revert TransferFailed();
            }
        }
    }
    
    /**
     * @notice Destroy contract and send remaining funds to owner
     * Use with extreme caution!
     */
    function destroy() external onlyOwner {
        // Withdraw all tokens first
        uint256 wmaticBalance = IERC20(WMATIC).balanceOf(address(this));
        if (wmaticBalance > 0) {
            _transferToken(WMATIC, owner, wmaticBalance);
        }
        
        // Self destruct
        selfdestruct(payable(owner));
    }
}

// =============================================================================
// GODFLASH FACTORY (Optional - for deploying multiple instances)
// =============================================================================

contract GodFlashFactory {
    event GodFlashDeployed(address indexed deployer, address indexed instance);
    
    address public immutable WMATIC;
    address[] public deployedInstances;
    
    constructor(address _wmatic) {
        WMATIC = _wmatic;
    }
    
    function deploy() external returns (address instance) {
        GodFlash godflash = new GodFlash(WMATIC);
        instance = address(godflash);
        deployedInstances.push(instance);
        emit GodFlashDeployed(msg.sender, instance);
        return instance;
    }
    
    function getDeployedCount() external view returns (uint256) {
        return deployedInstances.length;
    }
    
    function getDeployedInstances() external view returns (address[] memory) {
        return deployedInstances;
    }
}
