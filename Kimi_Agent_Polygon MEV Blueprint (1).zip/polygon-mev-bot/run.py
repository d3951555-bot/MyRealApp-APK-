"""
Polygon God-Mode MEV Bot - Simple Runner
One-command entry point for the bot
"""

import asyncio
import sys
import argparse
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from bot import MEVBot
from config import config
import logging

# Setup logging
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Polygon God-Mode MEV Bot',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run.py              # Run bot in simulation mode
  python run.py --live       # Run bot with live trades
  python run.py --scan-only  # Run one scan cycle and exit
  python run.py --interval 5 # Set scan interval to 5 seconds
        """
    )
    
    parser.add_argument(
        '--live',
        action='store_true',
        help='Enable live trading (default: simulation mode)'
    )
    
    parser.add_argument(
        '--scan-only',
        action='store_true',
        help='Run one scan cycle and exit'
    )
    
    parser.add_argument(
        '--interval',
        type=float,
        default=config.SCAN_INTERVAL,
        help=f'Scan interval in seconds (default: {config.SCAN_INTERVAL})'
    )
    
    parser.add_argument(
        '--deploy',
        action='store_true',
        help='Deploy GodFlash contract and exit'
    )
    
    parser.add_argument(
        '--quick-deploy',
        action='store_true',
        help='Quick deploy GodFlash contract'
    )
    
    args = parser.parse_args()
    
    # Handle deployment
    if args.deploy:
        from deploy import deploy_godflash
        deploy_godflash()
        return
    
    if args.quick_deploy:
        from deploy import quick_deploy
        quick_deploy()
        return
    
    # Update config based on args
    if args.live:
        config.SIMULATION_MODE = False
        logger.warning("=" * 60)
        logger.warning("LIVE TRADING MODE ENABLED")
        logger.warning("REAL TRANSACTIONS WILL BE SENT!")
        logger.warning("=" * 60)
        
        # Confirm with user
        confirm = input("Are you sure you want to enable live trading? (yes/no): ")
        if confirm.lower() != 'yes':
            logger.info("Live trading cancelled. Running in simulation mode.")
            config.SIMULATION_MODE = True
    
    config.SCAN_INTERVAL = args.interval
    
    # Initialize and run bot
    bot = MEVBot()
    
    try:
        await bot.initialize()
        
        if args.scan_only:
            logger.info("Running single scan cycle...")
            await bot.scan_cycle()
            logger.info("Scan complete!")
            logger.info(f"Stats: {bot.stats}")
        else:
            await bot.run()
            
    except KeyboardInterrupt:
        logger.info("\nBot stopped by user")
        bot.stop()
    except Exception as e:
        logger.error(f"Bot error: {e}")
        raise


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Exiting...")
        sys.exit(0)
